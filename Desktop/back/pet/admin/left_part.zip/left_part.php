   <!-- left menu starts -->
        <div class="col-sm-2 col-lg-2">
            <div class="sidebar-nav">
                <div class="nav-canvas">
                    <div class="nav-sm nav nav-stacked">

                    </div>
                    <ul class="nav nav-pills nav-stacked main-menu">
                        
                        <li><a class="ajax-link" href="dashboard.php"><i class="glyphicon glyphicon-home"></i><span> Dashboard</span></a>
                        </li>
                        
                        <li class="accordion">
                            <a href="javascript:"><i class="glyphicon glyphicon-plus"></i><span> Users Mangement</span></a>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="user_listing.php">Users</a></li>
                                <li><a href="add_user.php">Add User</a></li>
                            </ul>
                        </li>
						<li class="accordion">
                            <a href="javascript:"><i class="glyphicon glyphicon-plus"></i><span> Category Mangement</span></a>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="category_listing.php">Categories</a></li>
                                <li><a href="add_category.php">Add Category</a></li>
                            </ul>
                        </li>
                        <li class="accordion">
                            <a href="javascript:"><i class="glyphicon glyphicon-plus"></i><span> Product Mangement</span></a>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="product_listing.php">Product</a></li>
                                <li><a href="add_product.php">Add Product</a></li>
                            </ul>
                        </li>
						<li class="accordion">
                            <a href="javascript:"><i class="glyphicon glyphicon-plus"></i><span> Breed Mangement</span></a>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="dog_listing.php">Breed</a></li>
                                <li><a href="add_dog.php">Add Breed</a></li>
                            </ul>
                        </li>
                        
                    </ul>
                    
                </div>
            </div>
        </div>
        <!--/span-->
        <!-- left menu ends -->

        <noscript>
            <div class="alert alert-block col-md-12">
                <h4 class="alert-heading">Warning!</h4>

                <p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a>
                    enabled to use this site.</p>
            </div>
        </noscript>